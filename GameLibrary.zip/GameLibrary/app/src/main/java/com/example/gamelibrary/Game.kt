package com.example.gamelibrary

data class Game(
    var title: String,
    var publisher: String,
    var genre: String,
    var recommended: Boolean
)
